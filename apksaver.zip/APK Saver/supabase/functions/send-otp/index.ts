// APK Saver — send-otp edge function
// Generates a 6-digit OTP, returns its hash + expiry to the client (which
// stores it in Firestore), and emails the OTP to the allowed Gmail via Resend.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const ALLOWED_EMAIL = "mdromjan9522@gmail.com";

async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const hashBuf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hashBuf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
    if (!RESEND_API_KEY) {
      throw new Error("RESEND_API_KEY is not configured");
    }

    const body = await req.json().catch(() => ({}));
    const email = String(body?.email || "").trim().toLowerCase();

    if (email !== ALLOWED_EMAIL) {
      return new Response(
        JSON.stringify({ error: "This email is not authorized." }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const hash = await sha256Hex(otp);
    const expiresAt = Date.now() + 10 * 60 * 1000; // 10 min

    // Send via Resend (uses their test sender — no domain verification needed)
    const resendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "APK Saver <onboarding@resend.dev>",
        to: [ALLOWED_EMAIL],
        subject: `Your APK Saver password reset code: ${otp}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 480px; margin: auto; padding: 24px; background: #f8f8fb; border-radius: 12px;">
            <h2 style="color: #6b46f1; margin: 0 0 12px;">APK Saver</h2>
            <p style="color: #333; font-size: 14px;">Your password reset code:</p>
            <div style="font-size: 32px; font-weight: bold; letter-spacing: 8px; text-align: center; padding: 16px; background: white; border-radius: 8px; color: #1a1a2e;">
              ${otp}
            </div>
            <p style="color: #666; font-size: 12px; margin-top: 16px;">This code expires in 10 minutes.</p>
          </div>
        `,
      }),
    });

    const resendData = await resendRes.json().catch(() => ({}));
    if (!resendRes.ok) {
      console.error("Resend error:", resendRes.status, resendData);
      return new Response(
        JSON.stringify({
          error: "Failed to send email",
          details: resendData,
        }),
        {
          status: 502,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    // Return hash + expiry so the client can store it in Firestore.
    return new Response(
      JSON.stringify({ ok: true, hash, expiresAt }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    console.error("send-otp error:", msg);
    return new Response(
      JSON.stringify({ error: msg }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
