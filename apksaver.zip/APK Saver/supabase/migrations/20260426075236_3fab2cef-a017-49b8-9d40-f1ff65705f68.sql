
-- Create public bucket for APKs and images
INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('apks', 'apks', true, 524288000) -- 500MB limit
ON CONFLICT (id) DO UPDATE SET public = true, file_size_limit = 524288000;

-- Public read
CREATE POLICY "Public can read apks bucket"
ON storage.objects FOR SELECT
USING (bucket_id = 'apks');

-- Open write (single-admin app, gated by frontend auth)
CREATE POLICY "Anyone can upload to apks bucket"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'apks');

CREATE POLICY "Anyone can update apks bucket"
ON storage.objects FOR UPDATE
USING (bucket_id = 'apks');

CREATE POLICY "Anyone can delete from apks bucket"
ON storage.objects FOR DELETE
USING (bucket_id = 'apks');
